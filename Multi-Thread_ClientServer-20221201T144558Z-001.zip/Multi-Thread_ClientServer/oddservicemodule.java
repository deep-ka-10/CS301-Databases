Create or replace function checkif(IN train__no INT,IN datee VARCHAR(100) ,IN ctype CHAR(2), IN n_pass INT, IN namearray text[] )
returns text as $$
DECLARE 
ppnr  text;
temp time;
a INT;
i INT :=1;
present INT;
result text :=' ';
s INT;
num_ac INT;
num_sl INT;
coach_no INT;
berth_no INT;
berth_ty char(2);
BEGIN
	 PERFORM * FROM train WHERE train.train_no = train__no AND train.date=datee FOR UPDATE;
       SELECT COUNT(*) into present   FROM train WHERE train.train_no =train__no AND train.date=datee;
       SELECT train.ac_seats into a FROM train WHERE train.train_no =train__no AND train.date=datee;
       SELECT train.sl_seats into s FROM train WHERE train.train_no =train__no AND train.date=datee;
       SELECT train.ac_coaches into num_ac FROM train WHERE train.train_no = train__no AND train.date=datee;
    	SELECT train.sl_coaches into num_sl FROM train WHERE train.train_no =train__no AND train.date=datee;
	
      IF present <> 1 THEN
         result='-1';
	return result;
      END IF;
    	IF ctype= 'AC' AND a+n_pass<=num_ac*18 THEN
		UPDATE train SET ac_seats=a+n_pass  WHERE train_no=train__no and date=datee;
           
      END IF;
           
	IF ctype= 'SL' AND s+n_pass<=num_sl*24 THEN
		UPDATE train SET sl_seats=s+n_pass  WHERE train_no=train__no and date=datee;
           
    	END IF;
      
      temp =(select now());
      ppnr =ppnr || temp;
      result = result||' '|| ppnr || ' '||n_pass||' '||ctype;
      INSERT INTO tickets(pnr,train_no,doj,coach_type,num_pass) VALUES(ppnr,train__no,datee,ctype,n_pass);

      IF ctype='AC' THEN
       while i<n_pass loop
      
                                     coach_no = (a + i - 1) / 18 + 1;
                                     berth_no = (a + i - 1) % 18 + 1;
                                   
                                    if berth_no % 6 = 1 OR berth_no % 6 = 2 
                                    THEN
                                        berth_ty = 'LB';
                                     elsif berth_no % 6 = 3 OR berth_no % 6 = 4 
                                        THEN
                                        berth_ty = 'UB';
                                     elsif berth_no % 6 = 5 
                                    THEN      
                                    berth_ty = 'SL';
                                     else 
                                        berth_ty = 'SU';
                                      end if;
            result = result||''|| namearray[i]||' '|| coach_no||' '||berth_no||' '||berth_ty   ;                    
       INSERT INTO passengers(name,coachno,berthno,berthtype,pnr) VALUES(nname[i],coach_no,berth_no,berth_ty,ppnr);

      i:=i+1; 
     

       end loop;
  else
            while i<n_pass loop
      
                                     coach_no = (a + i - 1) / 24 + 1;
                                     berth_no = (a + i - 1) % 24 + 1;
                                   
                                    if berth_no % 8 = 1 OR berth_no % 8 = 4 
                                    THEN
                                        berth_ty = 'LB';
                                     elsif berth_no % 8 = 2 OR berth_no % 8 = 5 
                                        THEN
                                        berth_ty = 'MB';
                                     elsif berth_no % 8 = 3 OR berth_no % 8 = 6 
                                        THEN
                                        berth_ty = 'UB';
                                     elsif berth_no % 6 = 7 
                                    THEN      
                                    berth_ty = 'SL';
                                     else 
                                        berth_ty = 'SU';
                                      end if;
            result = result||''|| namearray[i]||' '|| coach_no||' '||berth_no||' '||berth_ty   ;                            
       INSERT INTO passengers(name,coachno,berthno,berthtype,pnr) VALUES(nname[i],coach_no,berth_no,berth_ty,ppnr);

      i:=i+1; 
     

       end loop;
   

    END IF;
      

      
      return result;
	

end;

$$language plpgsql;









import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.sql.*;
import java.sql.Timestamp;
import java.util.Date;
import java.text.SimpleDateFormat;

class QueryRunner implements Runnable {
    // Declare socket for client access
    protected Socket socketConnection;

    public QueryRunner(Socket clientSocket) {
        this.socketConnection = clientSocket;
    }

    public void run() {
        try {
            // Reading data from client
            InputStreamReader inputStream = new InputStreamReader(socketConnection
                    .getInputStream());
            BufferedReader bufferedInput = new BufferedReader(inputStream);
            OutputStreamWriter outputStream = new OutputStreamWriter(socketConnection
                    .getOutputStream());
            BufferedWriter bufferedOutput = new BufferedWriter(outputStream);
            PrintWriter printWriter = new PrintWriter(bufferedOutput, true);
            String clientCommand = "";
            String responseQuery = "";
            int ppid = 0;
            // Read client query from the socket endpoint
            clientCommand = bufferedInput.readLine();
            while (!clientCommand.equals("#")) {

                System.out.println("Recieved data <" + clientCommand + "> from client : "
                        + socketConnection.getRemoteSocketAddress().toString());

                /*******************************************
                 * Your DB code goes here
                 ********************************************/
                Connection c = null;
                Statement stmt = null;
                // Statement stmt1 = null;
                // Statement stmt2 = null;
                try {

                    c = DriverManager
                            .getConnection("jdbc:postgresql://localhost:5432/postgres",
                                    "postgres", "postgre123");

                    System.out.println("Opened database successfully");
                    stmt = c.createStatement();

                    String[] splited = clientCommand.split("\\,\\s+|\\s+");
                    int length_in = splited.length;

                    if (length_in > 4) {
                        int trainno = Integer.parseInt(splited[length_in - 3]);
                        int npass = Integer.parseInt(splited[0]);
                        String doj = splited[length_in - 2];
                        String ctype = splited[length_in - 1];
                        String[] namearray = new String[npass];
                        for(int i=0;i<npass;i++){
                            namearray[i]=splited[i+1];
                        }
                        // int count = -1;
                        // ResultSet rs3 = stmt.executeQuery("SELECT COUNT(*) as total FROM tickets");
                        // System.out.println(rs3 );
                        // System.out.println(rs3.next() );
                        // while (rs3.next()) {
                        // count = rs3.getInt("total");
                        // System.out.println("its working" );
                        // System.out.println(count );

                        // }
                        // int pnr = count + 100000;
                        // int trainno = Integer.parseInt(splited[length_in - 3]);
                        String sqlq = "select checkif(?,?,?,?,?)";

                        // Preparing a CallableStateement
                        CallableStatement cstmnt = c.prepareCall(sqlq);
                        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                        String pnr = dateFormat.format(new Date());

                        cstmnt.setInt(1, trainno);
                        cstmnt.setString(2, doj);
                        cstmnt.setString(3, ctype);
                        cstmnt.setInt(4, npass);
                        cstmnt.setString(5, pnr);
                        cstmnt.setArray(6, namearray);

                        ResultSet rs = cstmnt.executeQuery();
                        int result = -4;

                        while (rs.next()) {
                            result = rs.getInt(1);
                        }
                        System.out.println(result); 
                        if (result == -1) {
                            System.out.println("Requested train is not released on demanded date");
                        }
                        if (result == -2) {
                            System.out.println("Requested train has no sufficient demanded coach type");
                        }
                        if (result > 0) {
                            if (splited[length_in - 1].equals("AC")) {
                                String qinsertticket = "select insertticket(?,?,?,?,?)";
                                CallableStatement cStmt = c.prepareCall(qinsertticket);
                                cStmt.setString(1, pnr);
                                cStmt.setInt(2, trainno);
                                cStmt.setString(3, splited[length_in - 2]);
                                cStmt.setString(4, splited[length_in - 1]);
                                cStmt.setInt(5, npass);

                                ResultSet rst = cstmnt.executeQuery();
                                while (rs.next()) {
                                    result = rs.getInt(1);
                                }
                                System.out.println(result); 
                                System.out.println("done till insertticket fun"); 

                                String onepassanger="";
                                for (int i = 1; i <= npass; i++) {
                                    ppid++;
                                    String insertp="select insertPass(?,?,?,?,?,?)";
                                    CallableStatement cStmtt = c.prepareCall(insertp);

                                    int coach_no = (result + i - 1) / 18 + 1;
                                    int berth_no = (result + i - 1) % 18 + 1;
                                    String berth_ty;
                                    if (berth_no % 6 == 1 || berth_no % 6 == 2) {
                                        berth_ty = "LB";
                                    } else if (berth_no % 6 == 3 || berth_no % 6 == 4) {
                                        berth_ty = "UB";
                                    } else if (berth_no % 6 == 5) {
                                        berth_ty = "SL";
                                    } else {
                                        berth_ty = "SU";
                                    }
                                    //cStmtt.setInt(1, ppid);
                                    cStmtt.setString(1, pnr);
                                    cStmtt.setString(2, splited[i]);
                                    cStmtt.setInt(3, coach_no);
                                    cStmtt.setInt(4, berth_no);
                                    cStmtt.setString(5, berth_ty);
                                   
                                    
                                    rst =cStmtt.executeQuery();
                                    System.out.println("done till insertPass fun"); 

                                    String scoach_no = String.valueOf(coach_no);
                                    String sberth_no = String.valueOf(berth_no);

                                    String spnr = String.valueOf(pnr);
                                    String strainno = String.valueOf(trainno);
                                    onepassanger = spnr + strainno + splited[length_in - 2] + splited[i] + scoach_no
                                            + sberth_no + berth_ty + "\n";
                                }
                                responseQuery = responseQuery.concat(onepassanger);

                            }
                            if (splited[length_in - 1].equals("SL")) {
                                String qinsertticket = "{call insertticket(?,?,?,?,?)}";
                                CallableStatement cStmt = c.prepareCall(qinsertticket);
                                cStmt.setString(1, pnr);
                                cStmt.setInt(2, trainno);
                                cStmt.setString(3, splited[length_in - 2]);
                                cStmt.setString(4, splited[length_in - 1]);
                                cStmt.setInt(5, npass);

                                ResultSet rst = cstmnt.executeQuery();
                                System.out.println("done till insertticket fun"); 


                                String onepassanger="";
                                for (int i = 1; i <= npass; i++) {
                                    ppid++;
                                    cStmt = c.prepareCall("{call insertpass(?,?,?,?,?)}");

                                    int coach_no = (result + i - 1) / 24 + 1;
                                    int berth_no = (result + i - 1) % 24 + 1;
                                    String berth_ty;
                                    if (berth_no % 8 == 1 || berth_no % 8 == 4) {
                                        berth_ty = "LB";
                                    } else if (berth_no % 8 == 2 || berth_no % 8 == 5) {
                                        berth_ty = "MB";
                                    } else if (berth_no % 8 == 3 || berth_no % 8 == 6) {
                                        berth_ty = "UB";
                                    } else if (berth_no % 8 == 7) {
                                        berth_ty = "SL";
                                    } else {
                                        berth_ty = "SU";
                                    }
                                    //cStmt.setInt(1, ppid);
                                    cStmt.setString(1, pnr);
                                    cStmt.setString(2, splited[i]);
                                    cStmt.setInt(3, coach_no);
                                    cStmt.setInt(4, berth_no);
                                    cStmt.setString(5, berth_ty);

                                    rst=cStmt.executeQuery();
                                    System.out.println("done till insertPass fun"); 

                                    String scoach_no = String.valueOf(coach_no);
                                    String sberth_no = String.valueOf(berth_no);

                                    String spnr = String.valueOf(pnr);
                                    String strainno = String.valueOf(trainno);
                                    onepassanger = spnr + strainno + splited[length_in - 2] + splited[i] + scoach_no
                                            + sberth_no + berth_ty + "\n";
                                }
                                responseQuery = responseQuery.concat(onepassanger);

                            }

                        }

                    }

                    else {
                        String qrelease="select release(?,?,?,?)";
                        CallableStatement cStmt = c.prepareCall(qrelease);
                        int trainno = Integer.parseInt(splited[0]);
                        // Date d = java.sql.Date.valueOf(splited[1]);
                        int ac_coaches = Integer.parseInt(splited[2]);
                        int sl_coaches = Integer.parseInt(splited[3]);
                        //System.out.println("An error has occurred1111vvvv.");

                        cStmt.setInt(1, trainno);
                        cStmt.setString(2, splited[1]);
                        cStmt.setInt(3, ac_coaches);
                        cStmt.setInt(4, sl_coaches);
                        cStmt.executeQuery();

                        responseQuery = "Train Released";
                        // Sending data back to the client
                        // printWriter.println(responseQuery);
                    }
                    

                } catch (SQLException se) {
                    se.printStackTrace();

                }
                // responseQuery=responseqery;
                // Sending data back to the client
                printWriter.println(responseQuery);
                // Read next client query
                clientCommand = bufferedInput.readLine();
            }
            inputStream.close();
            bufferedInput.close();
            outputStream.close();
            bufferedOutput.close();
            printWriter.close();
            socketConnection.close();

        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            System.exit(0);
        }
    }

}

/**
 * Main Class to controll the program flow
 */
public class ServiceModule {
    // Server listens to port
    static int serverPort = 7008;
    // Max no of parallel requests the server can process
    static int numServerCores = 5;

    // ------------ Main----------------------
    public static void main(String[] args) throws IOException {
        // Creating a thread pool
        ExecutorService executorService = Executors.newFixedThreadPool(numServerCores);

        try (// Creating a server socket to listen for clients
                ServerSocket serverSocket = new ServerSocket(serverPort)) {
            Socket socketConnection = null;

            // Always-ON server
            while (true) {
                System.out.println("Listening port : " + serverPort
                        + "\nWaiting for clients...");
                socketConnection = serverSocket.accept(); // Accept a connection from a client
                System.out.println("Accepted client :"
                        + socketConnection.getRemoteSocketAddress().toString()
                        + "\n");
                // Create a runnable task
                Runnable runnableTask = new QueryRunner(socketConnection);
                // Submit task for execution
                executorService.submit(runnableTask);
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
