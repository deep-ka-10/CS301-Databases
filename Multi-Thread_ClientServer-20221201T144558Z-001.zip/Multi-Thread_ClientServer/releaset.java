import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;


public class releaset{
    public static void main(String[] args) {
		BufferedReader reader;
        try {
            Connection c1 = null;
           Class.forName("org.postgresql.Driver");
           c1 = DriverManager
              .getConnection("jdbc:postgresql://localhost:5432/postgres","postgres", "postgre123");
              try {
                reader = new BufferedReader(new FileReader("trainshedule.txt"));
                String line;
                line = reader.readLine();
                while (!line.equals("#")) {
                    System.out.println(line);
                    String[] s= line.split("\\s+");
                    String qrelease="select release(?,?,?,?)";
                    CallableStatement cStmt = c1.prepareCall(qrelease);
                    int trainno = Integer.parseInt(s[0]);
                   
                    int ac_coaches = Integer.parseInt(s[2]);
                    int sl_coaches = Integer.parseInt(s[3]);
                   

                    cStmt.setInt(1, trainno);
                    cStmt.setString(2, s[1]);
                    cStmt.setInt(3, ac_coaches);
                    cStmt.setInt(4, sl_coaches);
                    cStmt.executeQuery();
                    line = reader.readLine();
                }
               
                reader.close();
                c1.close();
                }
                catch (IOException e) {
                e.printStackTrace();
                }
        }
         catch (Exception e) {
           e.printStackTrace();
           System.err.println(e.getClass().getName()+": "+e.getMessage());
           System.exit(0);
        }
        
	
       
	}
}
    

